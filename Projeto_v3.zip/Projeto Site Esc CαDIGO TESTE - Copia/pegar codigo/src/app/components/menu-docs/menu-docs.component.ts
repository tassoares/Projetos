import { Component } from '@angular/core';

@Component({
  selector: 'app-menu-docs',
  standalone: true,
  imports: [],
  templateUrl: './menu-docs.component.html',
  styleUrl: './menu-docs.component.scss'
})
export class MenuDocsComponent {
  
}
